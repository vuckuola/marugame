# Game Design Template

## Working title

Sparkbound

## One-sentence pitch

A fast puzzle-platformer where the player shoots a spark into the world, then teleports to it to cross gaps, solve puzzles, and outplay enemies.

## Genre

2D action puzzle-platformer.

## Target platform

- Desktop browser.
- Mobile browser as secondary target.

## Target session length

- 1 level: 1-3 minutes.
- 1 world: 10-15 minutes.
- Full MVP: 15-30 minutes.

## Core fantasy

Player feels agile, clever, and stylish. The main joy is chaining jump + spark + teleport + landing cleanly.

## Core loop

```txt
Enter level
  -> learn obstacle
  -> use movement + spark mechanic
  -> collect shards / secrets
  -> reach exit
  -> get rank
  -> unlock next level
```

## Signature mechanic

### Spark teleport

Player can fire a spark projectile. If spark hits a valid anchor, it sticks. Press the spark button again to teleport/zip toward the spark.

Rules:

- Spark has limited range.
- Spark can only attach to valid surfaces or anchors.
- Spark expires after a short duration.
- Teleport cancels some velocity but keeps momentum partially.
- Spark can activate switches.
- Spark can damage or stun specific enemies.

## Player verbs

Minimum MVP verbs:

- move left/right,
- jump,
- variable jump height,
- shoot spark,
- teleport to spark,
- stomp enemy,
- collect shard,
- activate checkpoint,
- enter door/goal.

Optional later verbs:

- dash,
- wall slide,
- wall jump,
- charge spark,
- ground pound,
- carry object.

## Level ingredients

### Terrain

- ground,
- floating platform,
- one-way platform,
- wall,
- slope later,
- breakable block later.

### Hazard

- spike,
- pit,
- laser,
- moving hazard,
- crushing block.

### Interactive object

- spark anchor,
- switch,
- timed door,
- moving platform,
- checkpoint,
- locked door,
- key crystal.

### Collectibles

- shard: common collectible,
- big shard: optional challenge collectible,
- time crystal: speedrun route reward.

## Enemy types

### Walker

Basic patrol enemy. Teaches stomp and avoidance.

### Flyer

Moves in sine-wave or small patrol. Teaches air timing.

### Shooter

Stationary or slow enemy that fires projectile. Teaches cover and spark movement.

### Chaser, later

Detects player and follows for short distance.

### Mini boss, later

Uses arena + spark anchors.

## Difficulty curve

### World 1

Teach movement and spark.

- Level 1: movement + jump.
- Level 2: spark anchor.
- Level 3: spark over pit.
- Level 4: enemy + spark.
- Level 5: combined challenge.

### World 2

Introduce switches, moving platforms, and shooter enemies.

### World 3

Introduce timed doors, vertical levels, and advanced chaining.

## Rank system

Rank is based on:

- clear time,
- shards collected,
- deaths,
- optional big shard.

```txt
S rank: fast, all shards, no death
A rank: good time or all shards
B rank: clear normally
C rank: clear with many deaths or slow time
```

## Save data

Save per level:

```ts
type LevelSave = {
  unlocked: boolean;
  cleared: boolean;
  bestTimeMs: number | null;
  bestRank: "S" | "A" | "B" | "C" | null;
  bestShards: number;
  bigShardCollected: boolean;
};
```
