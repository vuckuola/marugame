# Level Format

## Goal

Level harus dipisah dari code supaya mudah bikin banyak stage, balancing, dan testing.

## JSON level format

```ts
export type LevelData = {
  id: string;
  name: string;
  theme: "forest" | "cave" | "city" | "dream";

  width: number;
  height: number;
  tileSize: number;

  spawn: Point;
  goal: Point;

  layers: {
    terrain: number[][];
    decorBack?: number[][];
    decorFront?: number[][];
    hazards?: number[][];
  };

  objects: LevelObject[];
};

export type Point = {
  x: number;
  y: number;
};

export type LevelObject =
  | EnemyObject
  | CollectibleObject
  | CheckpointObject
  | AnchorObject
  | DoorObject
  | SwitchObject
  | MovingPlatformObject;
```

## Object examples

```ts
export type EnemyObject = {
  type: "enemy";
  enemyType: "walker" | "flyer" | "shooter";
  x: number;
  y: number;
  patrol?: {
    left: number;
    right: number;
  };
};

export type CollectibleObject = {
  type: "collectible";
  collectibleType: "shard" | "bigShard" | "timeCrystal";
  x: number;
  y: number;
};

export type CheckpointObject = {
  type: "checkpoint";
  x: number;
  y: number;
};

export type AnchorObject = {
  type: "sparkAnchor";
  x: number;
  y: number;
  anchorType: "normal" | "timed" | "switchOnly";
};

export type DoorObject = {
  type: "door";
  id: string;
  x: number;
  y: number;
  lockedBy?: string;
};

export type SwitchObject = {
  type: "switch";
  id: string;
  x: number;
  y: number;
  target: string;
  activation: "touch" | "spark";
};

export type MovingPlatformObject = {
  type: "movingPlatform";
  x: number;
  y: number;
  w: number;
  h: number;
  path: Point[];
  speed: number;
};
```

## Example level

```json
{
  "id": "level-01",
  "name": "First Spark",
  "theme": "forest",
  "width": 80,
  "height": 12,
  "tileSize": 48,
  "spawn": { "x": 96, "y": 384 },
  "goal": { "x": 3600, "y": 336 },
  "layers": {
    "terrain": [],
    "hazards": []
  },
  "objects": [
    { "type": "collectible", "collectibleType": "shard", "x": 320, "y": 240 },
    { "type": "sparkAnchor", "anchorType": "normal", "x": 640, "y": 240 },
    { "type": "checkpoint", "x": 1200, "y": 336 },
    { "type": "enemy", "enemyType": "walker", "x": 1500, "y": 336, "patrol": { "left": 1400, "right": 1700 } }
  ]
}
```

## Tile IDs

Initial tile ID convention:

```txt
0   empty
1   ground solid
2   ground top
3   wall
4   one-way platform
5   spike
6   breakable block
7   decorative grass
8   decorative rock
```

## Collision tile rules

```ts
type TileRule = {
  solid: boolean;
  oneWay?: boolean;
  hazard?: boolean;
  breakable?: boolean;
};
```

## Level loader responsibilities

`LevelLoader` should:

1. Load JSON.
2. Validate required fields.
3. Build `Tilemap`.
4. Spawn objects using `ObjectFactory`.
5. Set spawn and goal.
6. Return `Level` instance.

## Tiled migration notes

When moving to Tiled:

- terrain layer becomes tile layer,
- hazard layer becomes tile layer,
- objects become object layer,
- object custom properties map to `enemyType`, `anchorType`, `target`, etc.
