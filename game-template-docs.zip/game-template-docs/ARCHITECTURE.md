# Architecture

## High-level architecture

```txt
Browser
  ├─ DOM/CSS UI Layer
  │   ├─ Title screen
  │   ├─ Pause menu
  │   ├─ Settings
  │   ├─ Level select
  │   ├─ Clear / Game Over screen
  │   └─ Touch controls
  │
  └─ Canvas Game Layer
      ├─ Fixed timestep loop
      ├─ Renderer
      ├─ Camera
      ├─ Tilemap
      ├─ Collision
      ├─ Entities
      ├─ Particles
      └─ HUD
```

## Folder structure

```txt
new-game/
  index.html
  package.json
  vite.config.ts

  public/
    assets/
      atlas.png
      atlas.json
      audio/
      bg/
      maps/
        level-01.json
        level-02.json

  src/
    main.ts

    core/
      Game.ts
      Loop.ts
      Renderer.ts
      Assets.ts
      Input.ts
      Audio.ts
      Camera.ts
      Storage.ts
      Debug.ts

    world/
      Level.ts
      Tilemap.ts
      Collision.ts
      LevelLoader.ts
      ObjectFactory.ts

    entities/
      Entity.ts
      Player.ts
      Enemy.ts
      Projectile.ts
      Item.ts
      Particle.ts
      MovingPlatform.ts

    gameplay/
      GameState.ts
      CombatSystem.ts
      CollectibleSystem.ts
      CheckpointSystem.ts
      ProgressionSystem.ts
      RankSystem.ts

    ui/
      HUD.ts
      OverlayManager.ts
      TouchControls.ts
      LevelSelect.ts

    data/
      config.ts
      balance.ts
      animations.ts
      enemyTypes.ts
```

## Core principles

1. **Core engine tidak boleh terlalu spesifik ke satu game.**
   `core/` harus bisa dipakai ulang untuk game 2D lain.

2. **Gameplay spesifik taruh di `gameplay/` dan `entities/`.**
   Spark teleport, enemy behavior, checkpoint, dan collectible logic jangan masuk ke `Renderer` atau `Loop`.

3. **Level harus data-driven.**
   Jangan hardcode level panjang di function besar. Pakai JSON/Tiled.

4. **Update dan render harus dipisah.**
   `update(dt)` mengubah state. `render()` hanya menggambar.

5. **Fixed timestep untuk gameplay.**
   Physics dan collision harus stabil di 60 FPS logic step.

## Main game loop

```ts
const STEP = 1000 / 60;
let last = performance.now();
let accumulator = 0;

function frame(now: number) {
  const delta = Math.min(100, now - last);
  last = now;
  accumulator += delta;

  while (accumulator >= STEP) {
    game.update(STEP / 1000);
    accumulator -= STEP;
  }

  game.render();
  requestAnimationFrame(frame);
}

requestAnimationFrame(frame);
```

## Game class

```ts
class Game {
  state: GameState;
  level: Level;
  renderer: Renderer;
  input: Input;
  camera: Camera;

  update(dt: number) {
    this.input.update();
    this.state.update(dt);

    if (this.state.isPlaying()) {
      this.level.update(dt, this.input);
      this.camera.follow(this.level.player);
    }
  }

  render() {
    this.renderer.clear();
    this.level.renderBackground(this.renderer, this.camera);
    this.level.render(this.renderer, this.camera);
    this.state.renderUI(this.renderer);
  }
}
```

## Entity interface

```ts
export interface Entity {
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  alive: boolean;

  update(dt: number, level: Level): void;
  render(renderer: Renderer): void;
}
```

## State model

```ts
export type GameMode =
  | "boot"
  | "title"
  | "levelSelect"
  | "playing"
  | "paused"
  | "clearing"
  | "gameOver"
  | "settings";
```

## Render order

```txt
1. Clear canvas
2. Parallax background
3. Far decor layer
4. Terrain tiles
5. One-way platforms
6. Hazards
7. Items / collectibles
8. Enemies
9. Projectiles / spark
10. Player
11. Particles / floating text
12. HUD
13. Debug overlays, if enabled
```

## Collision strategy

Use AABB + tile collision.

Recommended player movement order:

```txt
1. Apply input acceleration
2. Apply gravity
3. Move X
4. Resolve X collision
5. Move Y
6. Resolve Y collision
7. Update grounded / wall contact
8. Process interactions
```

## Camera

Camera should:

- follow player smoothly,
- clamp to level bounds,
- allow look-ahead based on player direction,
- support small screen shake,
- support debug camera free mode later.
