# New Game Template

Template ini dibuat untuk memulai **whole new browser game** berbasis arsitektur dari prototype platformer sebelumnya: Canvas 2D, custom game loop, tilemap, entity system, sprite atlas, DOM overlay, dan progression ringan.

Target template:

- Browser-first, ringan, dan mudah dipublish.
- Bisa jalan sebagai MVP cepat, tapi tetap scalable.
- Level tidak lagi hardcoded; level harus data-driven.
- Game feel harus jadi prioritas: movement, collision, camera, feedback, dan polish.

## Recommended concept

Nama kerja: **Sparkbound**

Genre: puzzle action platformer 2D.

Core hook:

> Player menembakkan spark ke anchor, lalu bisa teleport/zip ke posisi spark untuk menyelesaikan puzzle, menghindari hazard, dan mengalahkan musuh.

## File docs

- `ARCHITECTURE.md` — struktur engine dan module.
- `TECH_STACK.md` — teknologi yang dipakai.
- `GAME_DESIGN_TEMPLATE.md` — template konsep game baru.
- `LEVEL_FORMAT.md` — format level data-driven.
- `IMPLEMENTATION_ROADMAP.md` — urutan pengerjaan MVP sampai polish.
- `CHECKLIST.md` — checklist produksi.

## MVP target

MVP pertama harus punya:

- 1 playable character.
- 5 level pendek.
- 1 signature mechanic: spark teleport.
- 3 enemy type.
- checkpoint.
- collectibles.
- win/lose state.
- local save untuk best time dan unlocked level.
- desktop + mobile input.
