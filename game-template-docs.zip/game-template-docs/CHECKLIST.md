# Production Checklist

## Engine checklist

- [ ] Fixed timestep loop.
- [ ] Canvas renderer.
- [ ] Sprite atlas renderer.
- [ ] Keyboard input.
- [ ] Touch input.
- [ ] Camera follow.
- [ ] Camera clamp.
- [ ] Screen shake.
- [ ] Asset loader.
- [ ] Audio manager.
- [ ] Local save manager.
- [ ] Debug overlay.

## Player checklist

- [ ] Move left/right.
- [ ] Run acceleration.
- [ ] Friction.
- [ ] Gravity.
- [ ] Jump.
- [ ] Variable jump height.
- [ ] Coyote time.
- [ ] Jump buffer.
- [ ] Damage state.
- [ ] Invulnerability blink.
- [ ] Respawn.
- [ ] Spark shoot.
- [ ] Spark teleport.

## World checklist

- [ ] Tilemap.
- [ ] Solid collision.
- [ ] One-way platform.
- [ ] Hazards.
- [ ] Checkpoints.
- [ ] Goal.
- [ ] Moving platform.
- [ ] Switch.
- [ ] Door.
- [ ] Spark anchor.

## Enemy checklist

- [ ] Walker.
- [ ] Flyer.
- [ ] Shooter.
- [ ] Stomp kill.
- [ ] Spark stun/hit.
- [ ] Player damage.
- [ ] Patrol bounds.
- [ ] Ledge detection.

## Level checklist

- [ ] Level JSON format.
- [ ] Level loader.
- [ ] Object factory.
- [ ] Level 1.
- [ ] Level 2.
- [ ] Level 3.
- [ ] Level 4.
- [ ] Level 5.
- [ ] Secret collectible.
- [ ] Rank targets.

## UI checklist

- [ ] Title screen.
- [ ] Pause menu.
- [ ] Settings.
- [ ] Level select.
- [ ] Game over.
- [ ] Level clear.
- [ ] HUD.
- [ ] Timer display.
- [ ] Shard count.
- [ ] Rank display.
- [ ] Touch controls.

## Juice / polish checklist

- [ ] Jump dust.
- [ ] Landing dust.
- [ ] Spark trail.
- [ ] Teleport burst.
- [ ] Enemy defeat pop.
- [ ] Collectible sparkle.
- [ ] Screen shake.
- [ ] Hit pause.
- [ ] Smooth camera.
- [ ] Parallax background.
- [ ] SFX.
- [ ] BGM.

## Release checklist

- [ ] Works on desktop Chrome.
- [ ] Works on desktop Firefox.
- [ ] Works on desktop Safari.
- [ ] Works on Android Chrome.
- [ ] Works on iOS Safari.
- [ ] No console errors.
- [ ] Assets optimized.
- [ ] Production build passes.
- [ ] Deploy URL ready.
- [ ] Credits included.
