# Tech Stack

## Recommended stack

```txt
Language       : TypeScript
Build tool     : Vite
Renderer       : Canvas 2D custom renderer
Level editor   : Tiled Map Editor or custom JSON first
Asset format   : PNG sprite atlas + JSON metadata
Audio          : Web Audio or Howler.js
Save system    : localStorage
Deployment     : Vercel / Netlify / GitHub Pages
```

## Why this stack

### TypeScript

Dipakai supaya project lebih aman ketika mulai banyak entity, system, dan level data. Type untuk `Player`, `Enemy`, `LevelData`, `Tilemap`, dan `GameState` akan mengurangi bug.

### Vite

Dipakai sebagai dev server dan bundler modern. Cepat untuk development, mudah build static, cocok untuk browser game kecil-menengah.

### Canvas 2D

Renderer utama tetap Canvas 2D karena:

- ringan,
- cocok untuk pixel/platformer 2D,
- gampang dikontrol penuh,
- tidak perlu engine besar.

### DOM/CSS overlay

Canvas dipakai untuk game. DOM/CSS dipakai untuk:

- title screen,
- pause menu,
- settings,
- level select,
- game over,
- clear screen,
- mobile touch controls.

### Tiled Map Editor

Ideal untuk level production. Namun MVP awal boleh pakai JSON manual dulu. Setelah mechanic stabil, migrasi ke Tiled.

## Optional alternatives

### Phaser route

Gunakan Phaser kalau ingin engine siap pakai untuk scene, animation, tilemap, camera, dan physics. Tapi untuk project ini, custom mini-engine lebih disarankan karena kita ingin full control terhadap game feel.

### No TypeScript route

Boleh pakai JavaScript murni kalau ingin super cepat, tapi tidak disarankan untuk game yang akan berkembang banyak level dan entity.
