# Implementation Roadmap

## Phase 0 — Project setup

Goal: empty project runs in browser.

Tasks:

- Create Vite + TypeScript project.
- Setup canvas full game frame.
- Setup DOM overlay root.
- Add base CSS.
- Add `Game`, `Loop`, `Renderer`, `Input`.
- Draw test rectangle moving on screen.

Exit criteria:

- `npm run dev` works.
- Canvas renders.
- Keyboard input works.

## Phase 1 — Core platformer foundation

Goal: player can move in a tilemap.

Tasks:

- Implement fixed timestep loop.
- Implement camera follow.
- Implement tilemap.
- Implement AABB collision.
- Implement player movement:
  - acceleration,
  - friction,
  - gravity,
  - jump,
  - coyote time,
  - jump buffer,
  - variable jump height.

Exit criteria:

- Player can run and jump.
- Collision feels stable.
- Camera follows player.

## Phase 2 — Data-driven level

Goal: level comes from JSON, not hardcoded function.

Tasks:

- Create `LevelData` types.
- Create `LevelLoader`.
- Create `ObjectFactory`.
- Load `level-01.json`.
- Spawn player, terrain, goal, collectibles.

Exit criteria:

- New level can be created by editing JSON only.

## Phase 3 — Signature mechanic

Goal: spark teleport works.

Tasks:

- Add `SparkProjectile`.
- Add spark shooting input.
- Add spark anchor object.
- Add attach behavior.
- Add teleport/zip behavior.
- Add cooldown and expiration.
- Add particles and sound placeholder.

Exit criteria:

- Player can shoot spark to anchor and teleport to it.
- Spark is useful for crossing level gaps.

## Phase 4 — Game systems

Goal: game has complete level loop.

Tasks:

- Add collectibles.
- Add checkpoint.
- Add hazards and death/respawn.
- Add goal/level clear.
- Add timer.
- Add rank calculation.
- Add localStorage save.

Exit criteria:

- Player can clear level.
- Progress is saved.
- Level clear screen shows time/rank.

## Phase 5 — Enemies and combat

Goal: level has threats.

Tasks:

- Add walker enemy.
- Add flyer enemy.
- Add shooter enemy.
- Add stomp behavior.
- Add spark hit/stun behavior.
- Add player damage/invulnerability.

Exit criteria:

- 3 enemy types exist.
- Player can avoid, stomp, or spark-interact with enemies.

## Phase 6 — UI/UX

Goal: game feels like a product.

Tasks:

- Title screen.
- Pause menu.
- Game over screen.
- Clear screen.
- Level select.
- Settings menu.
- Touch controls.
- Control hints.

Exit criteria:

- User can start, pause, retry, select level, and play on mobile.

## Phase 7 — Content MVP

Goal: 5 levels ready.

Tasks:

- Level 1: movement tutorial.
- Level 2: spark tutorial.
- Level 3: spark + hazards.
- Level 4: enemies.
- Level 5: combined challenge.
- Add secrets and big shards.

Exit criteria:

- 5 levels playable from start to finish.

## Phase 8 — Polish

Goal: game feels satisfying.

Tasks:

- Sprite animation.
- Particle effects.
- Screen shake.
- Camera look-ahead.
- SFX.
- BGM.
- Better transition.
- Hit pause on impact.
- Floating score/text.
- Mobile layout polish.

Exit criteria:

- Game feels good, not just functional.

## Phase 9 — Release prep

Goal: public build.

Tasks:

- Add loading screen.
- Compress assets.
- Test Chrome/Safari/Firefox/mobile.
- Add README.
- Add credits.
- Build production.
- Deploy to Vercel/Netlify/GitHub Pages.

Exit criteria:

- Shareable public URL exists.
