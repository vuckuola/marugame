# Starter Prompt for Building the Game

Use this prompt when asking an AI/dev assistant to generate the initial project files.

```txt
Build a browser-first 2D puzzle-platformer called Sparkbound using Vite + TypeScript + Canvas 2D.

Architecture:
- fixed timestep loop at 60 FPS
- Canvas renderer
- DOM/CSS overlay for menus
- keyboard and touch input
- data-driven JSON levels
- AABB + tile collision
- entity update/render architecture
- localStorage progression

Core mechanic:
The player can shoot a spark projectile. If it hits a spark anchor, it sticks. Press the spark button again to teleport/zip to that spark.

Implement initial files:
- index.html
- package.json
- src/main.ts
- src/core/Game.ts
- src/core/Loop.ts
- src/core/Renderer.ts
- src/core/Input.ts
- src/core/Camera.ts
- src/world/Level.ts
- src/world/Tilemap.ts
- src/world/Collision.ts
- src/world/LevelLoader.ts
- src/entities/Entity.ts
- src/entities/Player.ts
- src/entities/Spark.ts
- src/entities/Enemy.ts
- src/gameplay/GameState.ts
- src/ui/HUD.ts
- public/assets/maps/level-01.json

MVP behavior:
- player can move and jump
- coyote time and jump buffer
- tile collision
- camera follow
- shoot spark
- teleport to spark anchor
- collect shards
- reach goal
- show clear state
```
